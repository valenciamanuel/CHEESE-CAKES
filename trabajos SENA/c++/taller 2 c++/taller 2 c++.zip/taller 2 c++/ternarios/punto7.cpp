#include <iostream>
using namespace std;

int main() {
    char letra;
    cout << "Ingresa un car�cter: ";
    cin >> letra;

    if ((letra >= 'a' && letra <= 'z') || (letra >= 'A' && letra <= 'Z')) {
        cout << "Es una letra." << endl;
    } else {
        cout << "No es una letra." << endl;
    }

    return 0;
}
