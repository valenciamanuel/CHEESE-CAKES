#include <stdio.h>
#include <string.h>

/*
 8. Sustituir todos los espacios en blanco de una frase por un asterisco.
 Desarrollado por sebas
 Version 5.11
 Junio 2024
 */

int main() {
    char frase[] = "la comida llena mucho .";
    for (int i = 0; i < strlen(frase); i++) {
        if (frase[i] == ' ') {
            frase[i] = '*';
        }
    }
    printf("%s", frase);
    return 0;
}
